<div class="galeri">
	<?php
	the_content(); 
	 ?>
</div>