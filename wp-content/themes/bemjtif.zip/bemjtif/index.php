<style>
	.container{
		margin-top: 60px;
	}
</style>

<?php get_header();?>
<main>
<div class="container">
	<?php dynamic_sidebar('sidebar2'); ?>
</div>
</main>

<div class="clearfix"></div>

<?php get_footer(); ?> 