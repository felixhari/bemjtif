<section id="visi">
	<div class="container">
		<div class="col-md-6">
			<h3>Visi</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime ex, temporibus culpa accusamus sequi nulla recusandae quis magnam ducimus repudiandae fugiat praesentium quas laboriosam officiis iusto, voluptas, delectus rem soluta!</p>
		</div>

		<div class="col-md-6">
			<h3>Misi</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime ex, temporibus culpa accusamus sequi nulla recusandae quis magnam ducimus repudiandae fugiat praesentium quas laboriosam officiis iusto, voluptas, delectus rem soluta!</p>
		</div>
	</div>
</section>